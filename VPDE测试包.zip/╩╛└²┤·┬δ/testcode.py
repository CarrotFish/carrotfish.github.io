print('Start')
while True:
    print('While')
    print('To-Do')
else:
    print('Last')
print('End')
